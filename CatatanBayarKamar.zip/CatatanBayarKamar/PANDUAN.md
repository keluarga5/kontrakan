# Catatan Bayar Kamar (proyek Android Studio)

## Membuat APK
1. Pasang Android Studio, lalu pilih File > Open dan buka folder ini.
2. Tunggu proses sync selesai (butuh internet, pertama kali agak lama).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Hasilnya ada di app/build/outputs/apk/debug/app-debug.apk. Kirim ke HP, lalu pasang (izinkan pemasangan dari sumber tidak dikenal).

## Menyiapkan Telegram
1. Di Telegram, buka @BotFather, kirim /newbot, ikuti langkahnya. Simpan token yang diberikan.
2. Buat grup keluarga, tambahkan bot itu, lalu jadikan admin dengan izin menyematkan pesan.
3. Cari Chat ID grup: kirim satu pesan di grup, lalu buka di browser
   https://api.telegram.org/bot<TOKEN>/getUpdates
   dan cari angka "id" di bagian "chat" (biasanya diawali -100).
4. Di aplikasi, buka tab Atur > Telegram, isi token dan Chat ID.
5. HP anggota keluarga: pasang APK yang sama, isi token dan Chat ID yang sama, lalu tekan "Ambil dari Telegram".

## Catatan
- Data utama disimpan di HP. Telegram dipakai sebagai cadangan dan sinkron: satu file yang disematkan di grup.
- Jika dua HP mengubah data bersamaan, yang terakhir mengubah yang dipakai.
- Token bot adalah kunci bot. Bagikan hanya ke keluarga. Anggota grup juga bisa membaca file cadangan.
- Data dari versi web tidak otomatis pindah ke aplikasi ini.
- Isi aplikasi ada di app/src/main/assets/index.html.

## Sinkron Telegram (versi 1.1)
- Mengirim dan mengambil berjalan otomatis: perubahan dikirim sekitar 3 detik setelah diubah, dan HP lain memeriksa Telegram tiap 15 detik selama aplikasi terbuka.
- Nama file cadangan: KODE KAMAR TERAKHIR YANG DIUBAH_TANGGAL_JAM WIB.json, contoh A101_17-11-2026_14.35 WIB.json.
- Status sinkron terakhir (berhasil atau error) tampil di tab Atur > Telegram.
- Bot harus admin grup dengan izin menyematkan pesan, karena aplikasi mencari cadangan lewat pesan yang disematkan.
- Memperbarui aplikasi: unggah ulang zip ke GitHub dengan nama sama, tunggu build selesai, lalu pasang APK baru. Versi ini memakai kunci tetap, jadi pembaruan berikutnya bisa dipasang di atas aplikasi lama tanpa menghapus data.
