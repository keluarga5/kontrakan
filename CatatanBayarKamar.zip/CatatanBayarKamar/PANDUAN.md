# Catatan Bayar Kamar (proyek Android Studio)

## Membuat APK
1. Pasang Android Studio, lalu pilih File > Open dan buka folder ini.
2. Tunggu proses sync selesai (butuh internet, pertama kali agak lama).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Hasilnya ada di app/build/outputs/apk/debug/app-debug.apk. Kirim ke HP, lalu pasang (izinkan pemasangan dari sumber tidak dikenal).

## Menyiapkan Telegram
1. Di Telegram, buka @BotFather, kirim /newbot, ikuti langkahnya. Simpan token yang diberikan.
2. Buat grup keluarga, tambahkan bot itu, lalu jadikan admin dengan izin menyematkan pesan.
3. Cari Chat ID grup: kirim satu pesan di grup, lalu buka di browser
   https://api.telegram.org/bot<TOKEN>/getUpdates
   dan cari angka "id" di bagian "chat" (biasanya diawali -100).
4. Di aplikasi, buka tab Atur > Telegram, isi token dan Chat ID.
5. HP anggota keluarga: pasang APK yang sama, isi token dan Chat ID yang sama, lalu tekan "Ambil dari Telegram".

## Catatan
- Data utama disimpan di HP. Telegram dipakai sebagai cadangan dan sinkron: satu file yang disematkan di grup.
- Jika dua HP mengubah data bersamaan, yang terakhir mengubah yang dipakai.
- Token bot adalah kunci bot. Bagikan hanya ke keluarga. Anggota grup juga bisa membaca file cadangan.
- Data dari versi web tidak otomatis pindah ke aplikasi ini.
- Isi aplikasi ada di app/src/main/assets/index.html.

## Sinkron Telegram (versi 1.1)
- Mengirim dan mengambil berjalan otomatis: perubahan dikirim sekitar 3 detik setelah diubah, dan HP lain memeriksa Telegram tiap 15 detik selama aplikasi terbuka.
- Nama file cadangan: KODE KAMAR TERAKHIR YANG DIUBAH_TANGGAL_JAM WIB.json, contoh A101_17-11-2026_14.35 WIB.json.
- Status sinkron terakhir (berhasil atau error) tampil di tab Atur > Telegram.
- Bot harus admin grup dengan izin menyematkan pesan, karena aplikasi mencari cadangan lewat pesan yang disematkan.
- Memperbarui aplikasi: unggah ulang zip ke GitHub dengan nama sama, tunggu build selesai, lalu pasang APK baru. Versi ini memakai kunci tetap, jadi pembaruan berikutnya bisa dipasang di atas aplikasi lama tanpa menghapus data.

## Versi 1.2
- Pembaruan dari dalam aplikasi: tab Atur > Aplikasi > Cek pembaruan, atau banner Update yang muncul otomatis di atas. Aplikasi memeriksa build terbaru di GitHub, mengunduh APK, lalu membuka pemasang Android. Tekan Perbarui lalu Buka. Android mewajibkan satu kali konfirmasi, jadi tidak bisa tanpa ketukan sama sekali. Repositori GitHub harus berstatus Public (isinya hanya kode dan APK, token bot tidak ada di dalamnya).
- Saat pertama menekan Update, Android akan meminta izin "pasang aplikasi dari sumber ini" untuk aplikasi ini. Aktifkan, lalu tekan Update lagi.
- Versi 1.2 bisa dipasang langsung di atas 1.1 tanpa menghapus.
- Saluran Telegram: Chat ID saluran data (file terbaru, ditimpa) dan Chat ID saluran arsip (opsional, setiap kirim jadi file baru). Jeda arsip diatur di Atur > Telegram. Bot harus admin di kedua saluran.
- Masa sewa habis: isi tanggal di rincian kamar. Pengingat dikirim ke saluran data saat tanggalnya tiba, sekali per kamar, dan terkirim ketika aplikasi sedang dibuka di salah satu HP.
- Kamar baru diisi hanya muncul mulai bulan "Mulai tinggal".


## Menjalankan via Link Web (iPhone / iOS & Browser)
Sistem ini berbasis Web App (HTML, CSS, JS), sehingga pengguna **iPhone / iOS** maupun laptop/PC dapat membukanya langsung via link browser (Safari/Chrome) tanpa perlu menginstal file APK.

### Cara Mengunggah agar Dapat Link Gratis:
1. **GitHub Pages (Gratis & Paling Praktis):**
   - Upload folder proyek ini ke repositori GitHub Anda.
   - Buka menu **Settings** repositori > **Pages**.
   - Pilih Branch `main` (atau `master`) dan folder `/` (root), lalu klik **Save**.
   - Dalam 1-2 menit, Anda akan mendapatkan link publik (contoh: `https://username.github.io/nama-repo/`).

2. **Netlify / Vercel (Gratis 1 Klik):**
   - Buka [netlify.com](https://www.netlify.com) atau [vercel.com](https://vercel.com).
   - Drag & drop file `index.html` (atau folder proyek), Anda akan langsung mendapatkan link URL unik secara gratis.

### Tips untuk Pengguna iPhone (iOS):
- Buka link URL tersebut di **Safari** iPhone.
- Tekan tombol **Share** (ikon panah ke atas di bagian bawah layar Safari).
- Pilih **"Add to Home Screen"** ("Tambah ke Layar Utama").
- Aplikasi akan muncul di layar utama iPhone seperti aplikasi native, dan data tetap tersinkron secara realtime via Telegram.
