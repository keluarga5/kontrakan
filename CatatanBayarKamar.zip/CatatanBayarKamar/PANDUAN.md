# Panduan Aplikasi Catatan Bayar Kamar

## Deskripsi
Aplikasi pencatatan pembayaran sewa kamar/kost yang mendukung sinkronisasi Telegram Web App dan multi-device cloud persistence.

## Mengatasi 'Failed to fetch' di Telegram Web App:
Penyebab utama error `Failed to fetch` saat ambil data dari Telegram:
1. **CORS Policy**: Server backend API harus mengizinkan origin dari Telegram. Header berikut telah ditambahkan/diperlukan di backend:
   `Access-Control-Allow-Origin: *`
   `Access-Control-Allow-Methods: GET, POST, OPTIONS`
   `Access-Control-Allow-Headers: Content-Type, Authorization`
2. **HTTPS/SSL Mandatory**: Telegram Web App dan API wajb menggunakan protokol HTTPS (`https://`).
3. **Telegram WebApp SDK Initialization**: Panggilan `window.Telegram.WebApp.ready()` dipastikan berjalan sebelum eksekusi sinkronisasi data.

## Cara Menggunakan:
1. Buka `index.html` langsung di browser atau dalam Telegram Web App.
2. Untuk build APK Android, buka folder proyek di Android Studio dan jalankan `Build APK`.
